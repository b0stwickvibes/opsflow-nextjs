// Shared: Forms

export { OriginalContactForm as RestaurantContactForm } from "./RestaurantContactForm";
export { RestaurantInquiryForm } from "./RestaurantInquiryForm";