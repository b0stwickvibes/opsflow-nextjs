// Semantic Hero Components - Restaurant Operations Focus
export { MarketingHero } from './MarketingHero';
export { ProductHero } from './ProductHero'; 
export { RestaurantHero } from './RestaurantHero';
export { CompanyHero } from './CompanyHero';