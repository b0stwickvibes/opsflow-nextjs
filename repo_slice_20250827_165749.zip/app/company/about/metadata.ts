import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "About Us",
  description: "Learn about OpsFlow AI, our mission to transform restaurant operations, and the team behind our platform.",
  openGraph: {
    title: "About Us | OpsFlow AI",
    description: "Learn about OpsFlow AI, our mission to transform restaurant operations, and the team behind our platform.",
  },
  twitter: {
    title: "About Us | OpsFlow AI",
    description: "Learn about OpsFlow AI, our mission to transform restaurant operations, and the team behind our platform.",
  },
}
